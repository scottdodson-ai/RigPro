import json
import os
import re
import tempfile
from datetime import datetime
from typing import Any, Dict, List

import pandas as pd
import gradio as gr

APP_TITLE = "Industrial Rigging JSA Wizard"

JOB_TYPES = [
    "Industrial Rigging",
    "Machinery Moving",
    "Heavy Haul Transport",
    "Combined Scope",
]

LIFT_TYPES = ["Standard Lift", "Critical Lift"]

COMM_METHODS = ["Hand Signals", "Radio", "Direct Verbal", "Mixed"]

PPE_OPTIONS = [
    "Hard hat",
    "Safety glasses",
    "High-visibility vest",
    "Cut-resistant gloves",
    "Steel-toe boots",
    "Hearing protection",
    "Fall protection",
]

HAZARD_OPTIONS = [
    "Suspended load",
    "Pinch / crush points",
    "Swing radius exposure",
    "Unstable / shifting load",
    "Unknown center of gravity",
    "Rigging overload risk",
    "Overhead obstructions",
    "Power lines / energized equipment",
    "Uneven ground / poor floor loading",
    "Traffic / public exposure",
    "Weather / wind",
    "Confined access / tight clearances",
    "Transport securement failure",
    "Trailer / route clearance issue",
]

CONTROL_OPTIONS = [
    "Pre-task crew review",
    "Dedicated signal person",
    "Exclusion zone established",
    "Test lift performed",
    "Tag lines used",
    "Spotters assigned",
    "Floor / ground bearing confirmed",
    "Load weight verified",
    "COG identified",
    "Rigging gear inspected",
    "Route survey completed",
    "Permits confirmed",
    "Weather checked",
    "Stop-work authority reviewed",
]

DEFAULT_STEPS = pd.DataFrame(
    [
        [1, "Arrive / stage equipment", "Site congestion, struck-by", "Barricades, staging plan, spotter"],
        [2, "Inspect rigging and equipment", "Damaged gear, hidden defects", "Pre-use inspection, remove defective gear"],
        [3, "Rig the load", "Wrong pick points, bad sling angle", "Verify pick points, angle, WLL, COG"],
        [4, "Test lift / initial movement", "Load shift, tip, binding", "Lift inches only, stop and verify balance"],
        [5, "Main lift / transfer", "Swing radius, line of fire", "Exclusion zone, one signal person, tag lines"],
        [6, "Set on skates / trailer / foundation", "Pinch / crush points", "Hands clear, use bars/tools, controlled lowering"],
        [7, "Final securement / set", "Unexpected movement", "Final check, blocking, securement verification"],
    ],
    columns=["Step #", "Task", "Hazards", "Controls"],
)


def normalize_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and pd.isna(value):
        return ""
    return str(value).strip()



def yes_no(value: bool) -> str:
    return "Yes" if value else "No"



def slugify(text: str) -> str:
    text = re.sub(r"[^A-Za-z0-9]+", "-", text.strip().lower())
    return text.strip("-") or "jsa"



def clean_steps(df: Any) -> List[Dict[str, str]]:
    if df is None:
        return []
    if isinstance(df, pd.DataFrame):
        rows = df.fillna("").to_dict(orient="records")
    elif isinstance(df, list):
        rows = []
        for row in df:
            if isinstance(row, dict):
                rows.append(row)
            elif isinstance(row, list) and len(row) >= 4:
                rows.append({
                    "Step #": row[0],
                    "Task": row[1],
                    "Hazards": row[2],
                    "Controls": row[3],
                })
    else:
        return []

    cleaned = []
    for row in rows:
        task = normalize_text(row.get("Task"))
        hazards = normalize_text(row.get("Hazards"))
        controls = normalize_text(row.get("Controls"))
        step_no = normalize_text(row.get("Step #"))
        if task or hazards or controls or step_no:
            cleaned.append(
                {
                    "step_number": step_no,
                    "task": task,
                    "hazards": hazards,
                    "controls": controls,
                }
            )
    return cleaned



def build_payload(
    project_name: str,
    job_type: str,
    location: str,
    customer: str,
    job_date: str,
    supervisor: str,
    crew: str,
    description: str,
    lift_type: str,
    load_weight_lb: str,
    dimensions: str,
    center_of_gravity: str,
    pick_points: str,
    equipment: str,
    rigging_gear: str,
    hazards: List[str],
    controls: List[str],
    comm_method: str,
    signal_person: str,
    spotters: str,
    ppe: List[str],
    exclusion_zone: str,
    tag_lines: bool,
    route_notes: str,
    permits: str,
    weather: str,
    stop_work_triggers: str,
    step_table: Any,
) -> Dict[str, Any]:
    payload = {
        "metadata": {
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "app": APP_TITLE,
            "version": "1.0",
        },
        "job_overview": {
            "project_name": normalize_text(project_name),
            "job_type": normalize_text(job_type),
            "location": normalize_text(location),
            "customer": normalize_text(customer),
            "job_date": normalize_text(job_date),
            "supervisor": normalize_text(supervisor),
            "crew": [x.strip() for x in normalize_text(crew).split(",") if x.strip()],
            "description": normalize_text(description),
            "lift_type": normalize_text(lift_type),
        },
        "load_and_rigging": {
            "load_weight_lb": normalize_text(load_weight_lb),
            "dimensions": normalize_text(dimensions),
            "center_of_gravity": normalize_text(center_of_gravity),
            "pick_points": normalize_text(pick_points),
            "equipment": normalize_text(equipment),
            "rigging_gear": normalize_text(rigging_gear),
        },
        "hazards": hazards or [],
        "controls": controls or [],
        "communication": {
            "method": normalize_text(comm_method),
            "signal_person": normalize_text(signal_person),
            "spotters": normalize_text(spotters),
            "exclusion_zone": normalize_text(exclusion_zone),
            "tag_lines_required": tag_lines,
        },
        "ppe": ppe or [],
        "transport": {
            "route_notes": normalize_text(route_notes),
            "permits": normalize_text(permits),
            "weather": normalize_text(weather),
        },
        "stop_work_triggers": normalize_text(stop_work_triggers),
        "job_steps": clean_steps(step_table),
    }
    return payload



def render_markdown(payload: Dict[str, Any]) -> str:
    jo = payload["job_overview"]
    lr = payload["load_and_rigging"]
    comm = payload["communication"]
    transport = payload["transport"]

    crew = ", ".join(jo.get("crew", [])) or "—"
    hazards = "\n".join([f"- {x}" for x in payload.get("hazards", [])]) or "- None listed"
    controls = "\n".join([f"- {x}" for x in payload.get("controls", [])]) or "- None listed"
    ppe = "\n".join([f"- {x}" for x in payload.get("ppe", [])]) or "- None listed"

    rows = payload.get("job_steps", [])
    if rows:
        table_lines = [
            "| Step | Task | Hazards | Controls |",
            "|---|---|---|---|",
        ]
        for row in rows:
            step = normalize_text(row.get("step_number")) or ""
            task = normalize_text(row.get("task")).replace("|", "/")
            hz = normalize_text(row.get("hazards")).replace("|", "/")
            ct = normalize_text(row.get("controls")).replace("|", "/")
            table_lines.append(f"| {step} | {task} | {hz} | {ct} |")
        steps_md = "\n".join(table_lines)
    else:
        steps_md = "No job steps entered."

    return f"""# Job Safety Analysis (JSA)

## Job Overview
- **Project / Job:** {jo.get('project_name') or '—'}
- **Job Type:** {jo.get('job_type') or '—'}
- **Location:** {jo.get('location') or '—'}
- **Customer / Site Contact:** {jo.get('customer') or '—'}
- **Date:** {jo.get('job_date') or '—'}
- **Supervisor / Lift Director:** {jo.get('supervisor') or '—'}
- **Crew:** {crew}
- **Scope:** {jo.get('description') or '—'}
- **Lift Classification:** {jo.get('lift_type') or '—'}

## Load & Rigging
- **Weight (lb):** {lr.get('load_weight_lb') or '—'}
- **Dimensions:** {lr.get('dimensions') or '—'}
- **Center of Gravity:** {lr.get('center_of_gravity') or '—'}
- **Pick Points:** {lr.get('pick_points') or '—'}
- **Primary Equipment:** {lr.get('equipment') or '—'}
- **Rigging Gear:** {lr.get('rigging_gear') or '—'}

## Hazards Identified
{hazards}

## Control Measures
{controls}

## Communication Plan
- **Method:** {comm.get('method') or '—'}
- **Signal Person:** {comm.get('signal_person') or '—'}
- **Spotters:** {comm.get('spotters') or '—'}
- **Exclusion Zone:** {comm.get('exclusion_zone') or '—'}
- **Tag Lines Required:** {yes_no(bool(comm.get('tag_lines_required')))}

## PPE
{ppe}

## Transport / Route Notes
- **Route Notes:** {transport.get('route_notes') or '—'}
- **Permits:** {transport.get('permits') or '—'}
- **Weather:** {transport.get('weather') or '—'}

## Stop-Work Triggers
{payload.get('stop_work_triggers') or '—'}

## Job Steps
{steps_md}
"""



def write_export_files(payload: Dict[str, Any]) -> tuple[str, str]:
    job_name = payload.get("job_overview", {}).get("project_name") or "jsa"
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_name = slugify(job_name)
    temp_dir = tempfile.mkdtemp(prefix="jsa_wizard_")

    json_path = os.path.join(temp_dir, f"{safe_name}_{stamp}.json")
    md_path = os.path.join(temp_dir, f"{safe_name}_{stamp}.md")

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write(render_markdown(payload))

    return json_path, md_path



def generate_outputs(*args):
    payload = build_payload(*args)
    pretty_json = json.dumps(payload, indent=2)
    markdown = render_markdown(payload)
    json_path, md_path = write_export_files(payload)

    warning_bits = []
    if payload["job_overview"].get("lift_type") == "Critical Lift":
        warning_bits.append("Critical lift selected: require detailed lift plan and supervisor sign-off.")
    if not payload["load_and_rigging"].get("load_weight_lb"):
        warning_bits.append("Load weight is blank. Verify exact weight before execution.")
    if not payload["load_and_rigging"].get("center_of_gravity"):
        warning_bits.append("Center of gravity is blank. Confirm before the pick.")
    if not payload["communication"].get("signal_person"):
        warning_bits.append("No signal person listed.")
    if not payload["job_steps"]:
        warning_bits.append("No job steps entered.")

    status = "\n".join([f"- {x}" for x in warning_bits]) if warning_bits else "- JSA draft generated successfully. Review with crew before field use."
    return pretty_json, markdown, json_path, md_path, status


with gr.Blocks(title=APP_TITLE) as demo:
    gr.Markdown(
        """
# Industrial Rigging JSA Wizard
Build a field-ready Job Safety Analysis for **industrial rigging**, **machinery moving**, and **heavy haul transport**.
Use the form, review the generated JSON + markdown, then download both files.
        """
    )

    with gr.Tab("1) Job Info"):
        with gr.Row():
            project_name = gr.Textbox(label="Project / Job Name", placeholder="Plant 3 Press Move")
            job_type = gr.Dropdown(JOB_TYPES, value="Industrial Rigging", label="Job Type")
        with gr.Row():
            location = gr.Textbox(label="Location")
            customer = gr.Textbox(label="Customer / Site Contact")
            job_date = gr.Textbox(label="Date", placeholder="2026-04-22 or Apr 22, 2026")
        with gr.Row():
            supervisor = gr.Textbox(label="Supervisor / Lift Director")
            crew = gr.Textbox(label="Crew (comma-separated)", placeholder="John Doe, Jane Smith, Forklift Op")
            lift_type = gr.Radio(LIFT_TYPES, value="Standard Lift", label="Lift Classification")
        description = gr.Textbox(label="Scope of Work", lines=4, placeholder="Unload 22,000 lb CNC from trailer, set on skates, move 80 ft, final set on pads.")

    with gr.Tab("2) Load & Equipment"):
        with gr.Row():
            load_weight_lb = gr.Textbox(label="Load Weight (lb)")
            dimensions = gr.Textbox(label="Dimensions")
            center_of_gravity = gr.Textbox(label="Center of Gravity")
            pick_points = gr.Textbox(label="Pick Points / Lift Lugs")
        equipment = gr.Textbox(label="Primary Equipment", lines=3, placeholder="60T hydraulic crane, 15K forklift, 12-ton skates")
        rigging_gear = gr.Textbox(label="Rigging Gear", lines=3, placeholder="2 x 20' synthetic round slings, 4 shackles, spreader bar")

    with gr.Tab("3) Hazards & Controls"):
        hazards = gr.CheckboxGroup(HAZARD_OPTIONS, label="Hazards Identified")
        controls = gr.CheckboxGroup(CONTROL_OPTIONS, label="Control Measures")
        stop_work_triggers = gr.Textbox(
            label="Stop-Work Triggers",
            lines=4,
            value="Any load shift, equipment issue, communication failure, unsafe weather, route or floor condition change, or any unplanned condition.",
        )

    with gr.Tab("4) Communication / PPE / Transport"):
        with gr.Row():
            comm_method = gr.Dropdown(COMM_METHODS, value="Hand Signals", label="Communication Method")
            signal_person = gr.Textbox(label="Signal Person")
            spotters = gr.Textbox(label="Spotters / Positions")
        exclusion_zone = gr.Textbox(label="Exclusion Zone / Barricade Notes", lines=2)
        tag_lines = gr.Checkbox(label="Tag lines required", value=True)
        ppe = gr.CheckboxGroup(PPE_OPTIONS, value=["Hard hat", "Safety glasses", "Steel-toe boots", "High-visibility vest"], label="Required PPE")
        route_notes = gr.Textbox(label="Transport / Route Notes", lines=3, placeholder="Check overhead doors, floor loading, turning radius, bridge clearance, public traffic control.")
        permits = gr.Textbox(label="Permits / Escorts / Jurisdiction Notes", lines=2)
        weather = gr.Textbox(label="Weather / Site Conditions", lines=2)

    with gr.Tab("5) Step-by-Step JSA"):
        gr.Markdown("Edit the default steps to fit the specific job. Add or remove rows as needed.")
        step_table = gr.Dataframe(value=DEFAULT_STEPS, headers=["Step #", "Task", "Hazards", "Controls"], row_count=(7, "dynamic"), col_count=(4, "fixed"), interactive=True)

    generate_btn = gr.Button("Generate JSA", variant="primary")

    with gr.Tab("Outputs"):
        status = gr.Markdown()
        with gr.Row():
            json_preview = gr.Code(label="JSON Output", language="json")
            md_preview = gr.Markdown(label="Markdown Preview")
        with gr.Row():
            json_file = gr.File(label="Download JSON")
            md_file = gr.File(label="Download Markdown")

    inputs = [
        project_name,
        job_type,
        location,
        customer,
        job_date,
        supervisor,
        crew,
        description,
        lift_type,
        load_weight_lb,
        dimensions,
        center_of_gravity,
        pick_points,
        equipment,
        rigging_gear,
        hazards,
        controls,
        comm_method,
        signal_person,
        spotters,
        ppe,
        exclusion_zone,
        tag_lines,
        route_notes,
        permits,
        weather,
        stop_work_triggers,
        step_table,
    ]

    generate_btn.click(
        fn=generate_outputs,
        inputs=inputs,
        outputs=[json_preview, md_preview, json_file, md_file, status],
    )


if __name__ == "__main__":
    demo.launch()
