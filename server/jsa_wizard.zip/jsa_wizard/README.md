# Industrial Rigging JSA Wizard

Local Gradio wizard for building Job Safety Analyses (JSAs) for:
- Industrial rigging
- Machinery moving
- Heavy haul transport

## What it does
- Collects job details, hazards, controls, communication plan, PPE, and transport notes
- Lets you edit a step-by-step JSA table
- Generates:
  - structured JSON
  - readable Markdown report
- Provides downloadable files directly in the UI

## Run it

### 1. Create and activate a virtual environment
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Launch the app
```bash
python jsa_wizard.py
```

Then open the local Gradio URL shown in the terminal.

## Notes
- This is a strong starter scaffold, not a substitute for your lift planning standards, customer requirements, OSHA obligations, DOT rules, engineer review, or company SOPs.
- Best next upgrades:
  1. company branding and logo
  2. PDF export
  3. supervisor approval/signature capture
  4. critical-lift conditional fields
  5. customer-specific templates
  6. database storage and search
